function speedup = getSpeedup(t,tp)
speedup = t/tp;
end

