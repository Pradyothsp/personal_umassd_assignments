function efficiency = getEfficiency(sp,p)
efficiency = (sp/p)*100;
end

