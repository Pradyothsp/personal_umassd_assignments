import time


def time_consuming_function(_=None, sleep_time=5):
    time.sleep(sleep_time)
