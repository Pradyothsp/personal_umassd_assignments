function [m,n] = getMN(li)
if li==1 
    m=1; 
    n=1; 

elseif li==2
    m=1;
    n=2; 

elseif li==3 
    m=2;
    n=1; 

else 
    m=2;
    n=2; 
end
end

